export class MajiActor extends Actor {
  /**
   * Extends data from base Actor class
   */
  prepareData() {
    super.prepareData();
    return this.data;
  }
  /* -------------------------------------------- */
  /*  Socket Listeners and Handlers
    /* -------------------------------------------- */
  /** @override */
  async update(data, options = {}) {
    // Calculate affinity
    if (this.data.type == "monster" && data['data.details.grade']) {
      data['data.affinity.value'] = 2 * data['data.details.grade'];
      data['data.resistance.value'] = 2 * data['data.details.grade'];  
    }
    return super.update(data, options);
  }
  /* -------------------------------------------- */
  /** @override */
  async createOwnedItem(itemData, options) {
    return super.createOwnedItem(itemData, options);
  }
  /* -------------------------------------------- */
  /*  Rolls                                       */
  /* -------------------------------------------- */
  counterIncrement(featId, delta) {
    let items = this.items.filter((i) => i.id == featId);
    items[0].data['data']['counter'].value += delta;
  }

  rollSkill(skillId, options={}) {
    const label = CONFIG.MAJI.skills[skillId];

    const abl = this.data.data.skills[skillId];
    let parts = [];
    if (abl.value <= 4) {
      parts.push("2d4");
    } else if (abl.value <= 7 ) {
      parts.push("2d6");
    } else {
      parts.push("2d8");  
    }

    let rollMode = game.settings.get("core", "rollMode");
    let roll = new Roll(parts.join(" + "), {}).roll();
    roll.toMessage({
      speaker: ChatMessage.getSpeaker({actor: this}),
      flavor: `${label} Skill Test`
    }, { rollMode });
    return roll;
  }

  rollStat(statId, options={}) {
    const label = CONFIG.MAJI.stats[statId];
    let parts = [];
    if (options.empowered) {
      parts.push("2d8");
    } else {
      parts.push("2d6");  
    }

    let rollMode = game.settings.get("core", "rollMode");
    let roll = new Roll(parts.join(" + "), {}).roll();
    roll.toMessage({
      speaker: ChatMessage.getSpeaker({actor: this}),
      flavor: `${label} Attribute Test`
    }, { rollMode });
    return roll;
  }

  rollAttribute(attributeId, options={}) {
    const label = CONFIG.MAJI.attributes[attributeId];

    const abl = this.data.data.attributes[attributeId];
    let parts = [];
    if (abl.value <= 4) {
      parts.push("2d4");
    } else if (abl.value <= 7 ) {
      parts.push("2d6");
    } else {
      parts.push("2d8");  
    }

    let rollMode = game.settings.get("core", "rollMode");
    let roll = new Roll(parts.join(" + "), {}).roll();
    roll.toMessage({
      speaker: ChatMessage.getSpeaker({actor: this}),
      flavor: `${label} Attribute Test`
    }, { rollMode });
    return roll;
  }

  rollBinding(options={}) {
    let rollMode = game.settings.get("core", "rollMode");
    let roll = new Roll("d20", {}).roll();
    roll.toMessage({
      speaker: ChatMessage.getSpeaker({actor: this}),
      flavor: `${game.i18n.localize('MAJI.check.bind')}`
    }, { rollMode });
    return roll;
  }

  rollTrigger({threshold=0, condition=""}, options = {}) {
    let rollMode = game.settings.get("core", "rollMode");
    let roll = new Roll("1d6", {}).roll();
    roll.toMessage(
      {
        speaker: ChatMessage.getSpeaker({ actor: this }),
        flavor: `${CONFIG.MAJI.conditions[condition]}(${threshold}) ${game.i18n.localize("MAJI.technique.trigger")}`,
      },
      { rollMode }
    );
    return roll;
  }
}
