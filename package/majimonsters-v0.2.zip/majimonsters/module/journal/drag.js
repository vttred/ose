export const onJournalSheet = function () {
  Hooks.once("canvasReady", (cv) => {
    document.getElementById("board").addEventListener("drop", (event) => {
      // Try to extract the data
      let data;
      try {
        data = JSON.parse(event.dataTransfer.getData("text/plain"));
      } catch (err) {
        return;
      }
      _onDropImage(event, data);
    });
  });

  Hooks.on("renderJournalSheet", (sheet, html, data) => {
    html.find(".lightbox-image").each((i, div) => {
      div.setAttribute("draggable", true);
      div.addEventListener("dragstart", _onDragStart, false);
    });
  });

  function _onDragStart(event) {
    console.log(event);
    event.stopPropagation();
    let url = event.srcElement.style.backgroundImage
      .slice(4, -1)
      .replace(/"/g, "");
    const dragData = { type: "image", src: url };
    event.dataTransfer.setData("text/plain", JSON.stringify(dragData));
  }

  // Add a method to Tiles Layer to handle image dropping
  function _onDropImage(event, data) {
    if (data.type == "image") {
      let t = canvas.tiles.worldTransform;
      Tile.create({
        x: (event.clientX - t.tx) / canvas.stage.scale.x,
        y: (event.clientY - t.ty) / canvas.stage.scale.y,
        height: 250,
        width: 250,
        scale: 1,
        z: 400,
        img: data.src,
        hidden: false,
        locked: false,
        rotation: 0,
      }).then((data) => {
        let tile = canvas.tiles.placeables.filter((a) => a.id === data._id)[0];
        tile.update({ width: tile.height * tile.aspectRatio });
      });
    }
  }
};
