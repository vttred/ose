import { OseActor } from "./entity.js";
import { OseActorSheet } from "./actor-sheet.js";

/**
 * Extend the basic ActorSheet with some very simple modifications
 */
export class OseActorSheetCharacter extends OseActorSheet {
  constructor(...args) {
    super(...args);
  }

  /* -------------------------------------------- */

  /**
   * Extend and override the default options used by the 5e Actor Sheet
   * @returns {Object}
   */
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["ose", "sheet", "actor", "character"],
      template: "systems/ose/templates/actors/character-sheet.html",
      width: 450,
      height: 530,
      resizable: true,
      tabs: [
        {
          navSelector: ".tabs",
          contentSelector: ".sheet-body",
          initial: "attributes",
        },
      ],
    });
  }

  /**
   * Prepare data for rendering the Actor sheet
   * The prepared data object contains both the actor data as well as additional sheet options
   */
  getData() {
    const data = super.getData();

    // Settings
    data.config.variableWeaponDamage = game.settings.get(
      "ose",
      "variableWeaponDamage"
    );
    data.config.ascendingAC = game.settings.get("ose", "ascendingAC");
    data.config.individualInit = game.settings.get("ose", "individualInit");

    // Compute treasure
    let total = 0;
    data.owned.items.forEach((item) => {
      if (item.data.treasure) {
        total += item.data.quantity.value * item.data.cost;
      }
    });
    data.treasure = total;

    data.config.encumbrance = game.settings.get("ose", "encumbranceOption");
    let basic = data.config.encumbrance == "basic";
    // Compute encumbrance
    let totalWeight = 0;
    Object.values(data.owned).forEach((cat) => {
      cat.forEach((item) => {
        if (item.type == "item" && (!basic || item.data.treasure)) {
          totalWeight += item.data.quantity.value * item.data.weight;
        } else if (!basic) {
          totalWeight += item.data.weight;
        }
      });
    });
    data.encumbrance = {
      pct: Math.clamped(
        (100 * parseFloat(totalWeight)) / data.data.encumbrance.max,
        0,
        100
      ),
      max: data.data.encumbrance.max,
      encumbered: totalWeight > data.data.encumbrance.max,
      value: totalWeight,
    };

    if (data.data.config.movementAuto) {
      this._calculateMovement(data, totalWeight);
    }

    // Compute AC
    let baseAc = 9;
    let baseAac = 10;
    let shield = 0;
    data.owned.armors.forEach((a) => {
      if (a.data.equipped && a.data.type != "shield") {
        baseAc = a.data.ac.value;
        baseAac = a.data.aac.value;
      } else if (a.data.equipped && a.data.type == "shield") {
        shield = a.data.ac.value;
      }
    });
    data.data.aac.value = baseAac + data.data.scores.dex.mod + shield;
    data.data.ac.value = baseAc - data.data.scores.dex.mod - shield;
    return data;
  }

  _calculateMovement(data, weight) {
    if (data.config.encumbrance == "detailed") {
      if (weight > data.encumbrance.max) {
        data.data.movement.base = 0;
      } else if (weight > 800) {
        data.data.movement.base = 30;
      } else if (weight > 600) {
        data.data.movement.base = 60;
      } else if (weight > 400) {
        data.data.movement.base = 90;
      } else {
        data.data.movement.base = 120;
      }
    } else if (data.config.encumbrance == "basic") {
      let heaviest = 0;
      data.owned.armors.forEach((a) => {
        if (a.data.equipped) {
          if (a.data.type == "light" && heaviest == 0) {
            heaviest = 1;
          } else if (a.data.type == "heavy") {
            heaviest = 2;
          }
        }
      });
      switch (heaviest) {
        case 0:
          data.data.movement.base = 120;
          break;
        case 1:
          data.data.movement.base = 90;
          break;
        case 2:
          data.data.movement.base = 60;
          break;
      }
      if (weight > game.settings.get("ose", "significantTreasure")) {
        data.data.movement.base -= 30;
      }
    }
  }

  /* -------------------------------------------- */

  async _onQtChange(event) {
    event.preventDefault();
    const itemId = event.currentTarget.closest(".item").dataset.itemId;
    const item = this.actor.getOwnedItem(itemId);
    return item.update({ "data.quantity.value": parseInt(event.target.value) });
  }

  /**
   * Activate event listeners using the prepared sheet HTML
   * @param html {HTML}   The prepared HTML object ready to be rendered into the DOM
   */
  activateListeners(html) {
    // Everything below here is only needed if the sheet is editable
    if (!this.options.editable) return;

    // Update Inventory Item
    html.find(".item-edit").click((ev) => {
      const li = $(ev.currentTarget).parents(".item");
      const item = this.actor.getOwnedItem(li.data("itemId"));
      item.sheet.render(true);
    });

    // Delete Inventory Item
    html.find(".item-delete").click((ev) => {
      const li = $(ev.currentTarget).parents(".item");
      this.actor.deleteOwnedItem(li.data("itemId"));
      li.slideUp(200, () => this.render(false));
    });

    html.find(".item-create").click((event) => {
      event.preventDefault();
      const header = event.currentTarget;
      const type = header.dataset.type;
      const itemData = {
        name: `New ${type.capitalize()}`,
        type: type,
        data: duplicate(header.dataset),
      };
      delete itemData.data["type"];
      return this.actor.createOwnedItem(itemData);
    });

    //Toggle Equipment
    html.find(".item-toggle").click(async (ev) => {
      const li = $(ev.currentTarget).parents(".item");
      const item = this.actor.getOwnedItem(li.data("itemId"));
      await this.actor.updateOwnedItem({
        _id: li.data("itemId"),
        data: {
          equipped: !item.data.data.equipped,
        },
      });
    });

    html
      .find(".quantity input")
      .click((ev) => ev.target.select())
      .change(this._onQtChange.bind(this));

    html.find(".ability-score .attribute-name a").click((ev) => {
      let actorObject = this.actor;
      let element = event.currentTarget;
      let score = element.parentElement.parentElement.dataset.score;
      actorObject.rollCheck(score, { event: event });
    });

    html.find(".exploration .attribute-name a").click((ev) => {
      let actorObject = this.actor;
      let element = event.currentTarget;
      let expl = element.parentElement.parentElement.dataset.exploration;
      actorObject.rollExploration(expl, { event: event });
    });

    html.find(".ability-score .attribute-mod a").click((ev) => {
      let box = $(
        event.currentTarget.parentElement.parentElement.parentElement
      );
      box.children(".attribute-bonuses").slideDown(200);
    });

    html.find(".ability-score .attribute-bonuses a").click((ev) => {
      $(event.currentTarget.parentElement.parentElement).slideUp(200);
    });

    html.find(".inventory .item-titles .item-caret").click((ev) => {
      let items = $(event.currentTarget.parentElement.parentElement).children(
        ".item-list"
      );
      if (items.css("display") == "none") {
        let el = $(event.currentTarget).find(".fas.fa-caret-right");
        el.removeClass("fa-caret-right");
        el.addClass("fa-caret-down");
        items.slideDown(200);
      } else {
        let el = $(event.currentTarget).find(".fas.fa-caret-down");
        el.removeClass("fa-caret-down");
        el.addClass("fa-caret-right");
        items.slideUp(200);
      }
    });

    // Handle default listeners last so system listeners are triggered first
    super.activateListeners(html);
  }
}
