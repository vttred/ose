# Introduction
This unofficial Old School Essentials System for Foundry VTT is a module offering all the features you need to play BECMI D&D games on this virtual table.

Features include:
- A Character sheet with attributes, saving throws, attack stats, abilities, inventory, spells, languages and notes.
- A Monster sheet with abilities, saving throws, attacks, rollable treasure tables, morale, number appearing and reaction checks.
- A party overview app where you can track PC's resources and deal experience.
- An combat tracker with grouped initiative.

# Guides
- [Character Sheet](Character sheet guide)
- [Monster Sheet](monster-sheet)
- [Treasure Table](treasure-table)
- [Combat Tracker](combat-tracker)
- [Party Overview](party-overview)
- [Macros](macros)